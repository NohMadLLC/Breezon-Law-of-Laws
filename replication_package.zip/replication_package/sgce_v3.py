#!/usr/bin/env python3
# SGCE_v3 — with drift-invariant verdict + prereg manifest auto-writer
# Backward compatible: keeps stable/unstable outputs; adds drift_invariant.
# Artifacts: per-file JSONL metrics, per-file CSV, replication CSV/JSON, hashes.csv, prereg_manifest.json + .sha256.txt

import argparse, json, math, hashlib, os, sys, csv, time, glob
from pathlib import Path
import numpy as np

# ----------------------------
# Utilities
# ----------------------------
def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def write_jsonl(path: Path, rows):
    with path.open('w', encoding='utf-8') as f:
        for r in rows:
            f.write(json.dumps(r, separators=(',', ':')) + '\n')

def write_csv(path: Path, header, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)

def total_variation(p, q):
    return 0.5 * np.abs(p - q).sum()

def wasserstein1_discrete(P, Q):
    cP = np.cumsum(P)
    cQ = np.cumsum(Q)
    return np.abs(cP - cQ).sum()

# ----------------------------
# Windowing
# ----------------------------
def late_split(x: np.ndarray, N: int = None, windows: int = 2):
    if N is None or N > len(x):
        N = len(x)
    xlate = x[-N:]
    W = max(2, int(windows))
    size = len(xlate) // W
    parts = [xlate[i*size:(i+1)*size] for i in range(W)]
    # drop tail if not divisible
    parts = [p for p in parts if len(p) == size]
    return parts

# ----------------------------
# Histograms and entropy
# ----------------------------
def bit_histogram(bits: np.ndarray):
    n = len(bits)
    if n == 0:
        return np.array([0.5, 0.5])
    c0 = int((bits == 0).sum())
    c1 = n - c0
    return np.array([c0 / n, c1 / n])

def block_entropy(bits: np.ndarray, k: int) -> float:
    if len(bits) < k or k <= 0:
        return float('nan')
    codes = []
    code = 0
    mask = (1 << k) - 1
    for i, b in enumerate(bits):
        code = ((code << 1) & mask) | int(b)
        if i >= k - 1:
            codes.append(code)
    if not codes:
        return float('nan')
    counts = np.bincount(np.array(codes, dtype=np.int64), minlength=(1 << k))
    tot = counts.sum()
    if tot == 0:
        return float('nan')
    p = counts[counts > 0] / tot
    H = -np.sum(p * np.log2(p))
    return H / k

# ----------------------------
# Spectral flatness
# ----------------------------
def spectral_flatness(bits: np.ndarray):
    if len(bits) < 8:
        return float('nan')
    x = np.where(bits == 1, 1.0, -1.0)
    X = np.fft.rfft(x)
    Pxx = (X.real**2 + X.imag**2) / len(x)
    Pxx = Pxx[1:]  # drop DC
    Pxx = np.clip(Pxx, 1e-12, None)
    gm = np.exp(np.mean(np.log(Pxx)))
    am = np.mean(Pxx)
    return float(gm / am)

# ----------------------------
# Run-lengths and geometric fit
# ----------------------------
def run_lengths(bits: np.ndarray):
    if len(bits) == 0:
        return np.array([], dtype=int)
    runs = []
    cur = bits[0]
    k = 1
    for b in bits[1:]:
        if b == cur:
            k += 1
        else:
            runs.append(k)
            cur = b
            k = 1
    runs.append(k)
    return np.array(runs, dtype=int)

def geometric_p_hat(runs: np.ndarray):
    if len(runs) == 0:
        return float('nan')
    mu = runs.mean()
    if mu <= 0:
        return float('nan')
    return float(1.0 / mu)

def geometric_pmf(p: float, Lmax: int):
    L = np.arange(1, Lmax + 1)
    pmf = (1 - p) ** (L - 1) * p
    pmf /= pmf.sum()
    return pmf

def runlen_histogram(runs: np.ndarray, Lmax: int):
    if len(runs) == 0:
        return np.ones(Lmax) / Lmax
    counts = np.bincount(np.clip(runs, 1, Lmax), minlength=Lmax + 1)[1:Lmax + 1]
    p = counts / counts.sum() if counts.sum() > 0 else np.ones(Lmax) / Lmax
    return p

def runlen_geometric_w1(bits: np.ndarray, Lmax: int = 64):
    r = run_lengths(bits)
    p_hat = geometric_p_hat(r)
    if not np.isfinite(p_hat) or p_hat <= 0 or p_hat >= 1:
        p_hat = 0.5
    Pemp = runlen_histogram(r, Lmax)
    Pth = geometric_pmf(0.5, Lmax)
    W1_emp_th = wasserstein1_discrete(Pemp, Pth)
    W1_emp_empP = wasserstein1_discrete(Pemp, geometric_pmf(p_hat, Lmax))
    return {
        "p_hat": float(p_hat),
        "W1_emp_vs_theory_p05": float(W1_emp_th),
        "W1_emp_vs_emp_p": float(W1_emp_empP)
    }

# ----------------------------
# Observers and deltas
# ----------------------------
def window_metrics(bits: np.ndarray, kmax: int, Lmax: int, use_entropy=True, use_spectral=True, use_runs=True, ac_lags=0, pe_k=0):
    out = {}
    # bit histogram always
    p = bit_histogram(bits)
    out["p0"] = float(p[0]); out["p1"] = float(p[1])
    # entropies
    if use_entropy:
        for k in range(1, kmax + 1):
            out[f"H_{k}"] = float(block_entropy(bits, k))
    # spectral
    if use_spectral:
        out["SF"] = spectral_flatness(bits)
    # runs
    if use_runs:
        out.update(runlen_geometric_w1(bits, Lmax=Lmax))
    # optional autocorr
    if ac_lags > 0:
        x = np.where(bits == 1, 1.0, -1.0)
        mu = x.mean(); xv = x - mu
        denom = np.dot(xv, xv) + 1e-12
        for lag in range(1, ac_lags + 1):
            num = np.dot(xv[:-lag], xv[lag:]) if lag < len(xv) else 0.0
            out[f"AC_{lag}"] = float(num / denom)
    # optional permutation entropy (simple ordinal patterns of length pe_k)
    if pe_k and pe_k >= 3 and pe_k <= 7 and len(bits) >= pe_k:
        x = np.where(bits == 1, 1.0, -1.0)  # cheap embedding
        m = pe_k
        patterns = {}
        for i in range(0, len(x) - m + 1):
            idx = tuple(np.argsort(x[i:i+m]))
            patterns[idx] = patterns.get(idx, 0) + 1
        p = np.array(list(patterns.values()), dtype=float)
        p /= p.sum()
        H = -np.sum(p * np.log2(p))
        out[f"PE_{m}"] = float(H / math.log2(math.factorial(m)))
    return out

def compare_windows(a: dict, b: dict, kmax: int, use_entropy=True, use_spectral=True, use_runs=True, ac_lags=0, pe_k=0):
    deltas = {}
    # bits
    Pa = np.array([a["p0"], a["p1"]]); Pb = np.array([b["p0"], b["p1"]])
    deltas["tv_bits"] = float(total_variation(Pa, Pb))
    # entropies
    if use_entropy:
        for k in range(1, kmax + 1):
            ak = a.get(f"H_{k}", float('nan')); bk = b.get(f"H_{k}", float('nan'))
            deltas[f"dH_{k}"] = float(abs(ak - bk)) if (np.isfinite(ak) and np.isfinite(bk)) else float('nan')
    # spectral
    if use_spectral:
        sa, sb = a.get("SF", float('nan')), b.get("SF", float('nan'))
        deltas["dSF"] = float(abs(sa - sb)) if (np.isfinite(sa) and np.isfinite(sb)) else float('nan')
    # runs
    if use_runs:
        d1a, d1b = a.get("W1_emp_vs_theory_p05"), b.get("W1_emp_vs_theory_p05")
        d2a, d2b = a.get("W1_emp_vs_emp_p"), b.get("W1_emp_vs_emp_p")
        deltas["dW1_emp_vs_theory_p05"] = float(abs(d1a - d1b))
        deltas["dW1_emp_vs_emp_p"] = float(abs(d2a - d2b))
    # autocorr
    for lag in range(1, ac_lags + 1):
        ak = a.get(f"AC_{lag}", float('nan')); bk = b.get(f"AC_{lag}", float('nan'))
        deltas[f"dAC_{lag}"] = float(abs(ak - bk)) if (np.isfinite(ak) and np.isfinite(bk)) else float('nan')
    # permutation entropy
    if pe_k and pe_k >= 3:
        pa = a.get(f"PE_{pe_k}", float('nan')); pb = b.get(f"PE_{pe_k}", float('nan'))
        deltas[f"dPE_{pe_k}"] = float(abs(pa - pb)) if (np.isfinite(pa) and np.isfinite(pb)) else float('nan')
    return deltas

def pass_thresholds(deltas: dict, taus: dict, kmax: int, ac_lags=0, pe_k=0, use_entropy=True, use_spectral=True, use_runs=True):
    ok = True
    ok &= deltas["tv_bits"] < taus["bits"]
    if use_spectral and "dSF" in deltas:
        ok &= deltas["dSF"] < taus["sf"]
    if use_runs:
        ok &= deltas["dW1_emp_vs_theory_p05"] < taus["w1"]
        ok &= deltas["dW1_emp_vs_emp_p"] < taus["w1"]
    if use_entropy:
        for k in range(1, kmax + 1):
            dv = deltas.get(f"dH_{k}")
            if np.isfinite(dv):
                ok &= dv < taus["H"]
    for lag in range(1, ac_lags + 1):
        dv = deltas.get(f"dAC_{lag}")
        if np.isfinite(dv):
            ok &= dv < taus.get("ac", 0.02)
    if pe_k and pe_k >= 3:
        dv = deltas.get(f"dPE_{pe_k}")
        if np.isfinite(dv):
            ok &= dv < taus.get("pe", 0.02)
    return bool(ok)

# ----------------------------
# Drift detection (multi-scale shape)
# ----------------------------
def drift_signature(deltas_by_scale):
    """
    deltas_by_scale: dict W -> list of per-pair delta dicts for that W
    Heuristic drift-invariant criteria:
      (1) Not all-pass.
      (2) Monotone nondecreasing median(tv_bits) across W.
      (3) Fraction of failed metrics per scale is nondecreasing across W.
    Returns (is_drift, sig_dict)
    """
    scales = sorted(deltas_by_scale.keys())
    # build per-scale metrics
    med_tv = []
    fail_frac = []
    for W in scales:
        pairs = deltas_by_scale[W]
        tvs = [p["tv_bits"] for p in pairs if "tv_bits" in p]
        med_tv.append(np.median(tvs) if len(tvs) else np.nan)
        # count how many thresholds exceeded per pair, normalized
        fails = []
        for d in pairs:
            c = 0; n = 0
            for k, v in d.items():
                if not np.isfinite(v): 
                    continue
                n += 1
            # a rough fail fraction proxy; actual taus not here, so approximate using per-scale z to tv median
            # Instead, measure dispersion increase: large deltas relative to median across pairs
            # For drift test we use rank-based: if tv > median(tv of W=2) it's a "high" delta
            fails.append(0)  # placeholder; detailed fail count needs taus; we use monotone median only
        # use available tv-based signal only
        fail_frac.append(np.nan)  # kept for API, not used
    # condition (2): monotone nondecreasing med_tv
    def monotone_nondec(x):
        x = [z for z in x if np.isfinite(z)]
        return all(x[i] <= x[i+1] + 1e-12 for i in range(len(x)-1)) and len(x) >= 2
    is_drift = monotone_nondec(med_tv)
    sig = {"median_tv_by_scale": {str(W): float(med_tv[i]) if np.isfinite(med_tv[i]) else float('nan') 
                                  for i, W in enumerate(scales)}}
    return bool(is_drift), sig

# ----------------------------
# IO loaders
# ----------------------------
def load_bits_from_file(path: Path):
    sfx = path.suffix.lower()
    if sfx in ('.txt', '.log'):
        data = []
        with path.open('r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                for ch in line.strip():
                    if ch in ('0', '1'):
                        data.append(int(ch))
        return np.array(data, dtype=np.int8)
    elif sfx in ('.csv',):
        arr = np.loadtxt(str(path), delimiter=',', dtype=float)
        if arr.ndim > 1:
            arr = arr.ravel()
        if np.all((arr == 0) | (arr == 1)):
            return arr.astype(np.int8)
        thr = np.median(arr)
        return (arr > thr).astype(np.int8)
    else:
        raw = path.read_bytes()
        if not raw:
            return np.array([], dtype=np.int8)
        by = np.frombuffer(raw, dtype=np.uint8)
        bits = np.unpackbits(by)
        return bits.astype(np.int8)

# ----------------------------
# Per-file run (multi-scale)
# ----------------------------
def run_one(inpath: Path, out_root: Path, N, windows_list, kmax, Lmax, taus,
            use_entropy=True, use_spectral=True, use_runs=True, ac_lags=0, pe_k=0):
    art_dir = out_root / 'artifacts'
    art_dir.mkdir(parents=True, exist_ok=True)

    bits = load_bits_from_file(inpath)
    if len(bits) < 1024:
        return {"file": inpath.name, "error": f"too_few_bits:{len(bits)}"}

    per_scale_jsonl = []
    per_scale_pass = {}
    deltas_by_scale = {}

    for W in windows_list:
        parts = late_split(bits, N, W)
        # metrics for each window
        Ms = [window_metrics(p, kmax, Lmax, use_entropy, use_spectral, use_runs, ac_lags, pe_k) for p in parts]
        # pairwise deltas across adjacent windows
        deltas_pairs = []
        for i in range(len(Ms) - 1):
            d = compare_windows(Ms[i], Ms[i+1], kmax, use_entropy, use_spectral, use_runs, ac_lags, pe_k)
            deltas_pairs.append(d)
        deltas_by_scale[W] = deltas_pairs

        # pass if all adjacent pairs pass thresholds
        pair_pass = []
        for d in deltas_pairs:
            ok = pass_thresholds(d, taus, kmax, ac_lags, pe_k, use_entropy, use_spectral, use_runs)
            pair_pass.append(bool(ok))
            per_scale_jsonl.append({"scale_W": int(W), "pair": len(pair_pass), "deltas": d, "pass": bool(ok)})

        per_scale_pass[W] = all(pair_pass) if len(pair_pass) > 0 else False

    # decide verdict across scales
    all_pass = all(per_scale_pass.get(W, False) for W in windows_list)
    drift, sig = (False, {})
    if not all_pass:
        drift, sig = drift_signature(deltas_by_scale)

    verdict_label = "stable" if all_pass else ("drift_invariant" if drift else "unstable")

    # write JSONL metrics per file
    jsonl_path = art_dir / f"{inpath.stem}_multiscale_metrics.jsonl"
    write_jsonl(jsonl_path, per_scale_jsonl)

    # CSV summary per file
    header = ["file", "verdict"] + [f"W{W}_pass" for W in windows_list]
    row = [inpath.name, verdict_label] + [int(per_scale_pass.get(W, False)) for W in windows_list]
    csv_path = art_dir / f"{inpath.stem}_summary.csv"
    write_csv(csv_path, header, [row])

    out = {"file": inpath.name, "verdict": verdict_label, "jsonl": str(jsonl_path), "csv": str(csv_path)}
    if drift:
        out["drift_signature"] = sig
    return out

# ----------------------------
# Preregistration manifest
# ----------------------------
def write_prereg(out_root: Path, args, inglob_or_infile: str, observer_set: str):
    manifest = {
        "timestamp_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "engine": "sgce_v3.py",
        "params": {
            "N": args.N,
            "kmax": args.kmax,
            "Lmax": args.Lmax,
            "windows_list": args.windows_list,
            "tau_bits": args.tau_bits,
            "tau_sf": args.tau_sf,
            "tau_w1": args.tau_w1,
            "tau_H": args.tau_H,
            "tau_ac": getattr(args, "tau_ac", 0.02),
            "tau_pe": getattr(args, "tau_pe", 0.02)
        },
        "observer_set": observer_set,
        "observers_enabled": {
            "entropy": not args.disable_entropy,
            "spectral": not args.disable_spectral,
            "runs": not args.disable_runs,
            "autocorr_lags": args.add_autocorr_lags,
            "perm_entropy_k": args.add_perm_entropy
        },
        "datasets": {
            "input": inglob_or_infile
        },
        "anonymize": bool(args.anonymize)
    }
    p = out_root / "prereg_manifest.json"
    with p.open('w', encoding='utf-8') as f:
        json.dump(manifest, f, separators=(',', ':'))
    h = sha256_file(p)
    with (out_root / "prereg_manifest.sha256.txt").open('w', encoding='utf-8') as f:
        f.write(h + "\n")
    return str(p), h

# ----------------------------
# Main
# ----------------------------
def main():
    ap = argparse.ArgumentParser(description="SGCE v3 with drift-invariant + prereg manifest")
    ap.add_argument('--in', dest='infile', help='Single input file (txt/csv/bin)')
    ap.add_argument('--glob', dest='inglob', help='Glob of inputs, e.g. "./qrng/*.txt"')
    ap.add_argument('--out_dir', default='evidence', help='Output directory root')
    ap.add_argument('--N', type=int, default=1_000_000, help='Late-sample size')
    ap.add_argument('--kmax', type=int, default=8, help='Max block size for H_k')
    ap.add_argument('--Lmax', type=int, default=256, help='Max run length bucket')
    ap.add_argument('--windows_list', type=lambda s: [int(x) for x in s.split(',')], default=[2,4,8], help='Comma list, e.g., 2,4,8')
    # observers toggles
    ap.add_argument('--disable_entropy', action='store_true')
    ap.add_argument('--disable_spectral', action='store_true')
    ap.add_argument('--disable_runs', action='store_true')
    ap.add_argument('--add_autocorr_lags', type=int, default=0)
    ap.add_argument('--add_perm_entropy', type=int, default=0)
    # thresholds
    ap.add_argument('--tau_bits', type=float, default=0.002)
    ap.add_argument('--tau_sf', type=float, default=0.01)
    ap.add_argument('--tau_w1', type=float, default=0.01)
    ap.add_argument('--tau_H', type=float, default=0.008)
    ap.add_argument('--tau_ac', type=float, default=0.02)
    ap.add_argument('--tau_pe', type=float, default=0.02)
    # misc
    ap.add_argument('--anonymize', action='store_true')
    ap.add_argument('--no_prereg', action='store_true', help='Disable prereg manifest auto-write')
    args = ap.parse_args()

    # sanity on inputs
    if (args.infile is None) == (args.inglob is None):
        print(json.dumps({"error":"specify exactly one of --in or --glob"}, separators=(',', ':')))
        sys.exit(2)

    out_root = Path(args.out_dir); out_root.mkdir(parents=True, exist_ok=True)

    # observers config
    use_entropy = not args.disable_entropy
    use_spectral = not args.disable_spectral
    use_runs = not args.disable_runs
    ac_lags = max(0, int(args.add_autocorr_lags))
    pe_k = max(0, int(args.add_perm_entropy))

    observer_set = []
    if use_entropy: observer_set.append("entropy")
    if use_spectral: observer_set.append("spectral")
    if use_runs: observer_set.append("runs")
    if ac_lags>0: observer_set.append(f"ac{ac_lags}")
    if pe_k>0: observer_set.append(f"pe{pe_k}")
    observer_set = "+".join(observer_set) if observer_set else "none"

    # prereg manifest
    manifest_path = None; manifest_sha = None
    if not args.no_prereg:
        inglob_or_infile = args.inglob if args.inglob else str(Path(args.infile))
        manifest_path, manifest_sha = write_prereg(out_root, args, inglob_or_infile, observer_set)

    # taus bundle
    taus = {"bits": args.tau_bits, "sf": args.tau_sf, "w1": args.tau_w1, "H": args.tau_H, "ac": args.tau_ac, "pe": args.tau_pe}

    # run
    per_rows = []
    per_hash = []

    if args.inglob:
        files = sorted(glob.glob(args.inglob))
        if not files:
            print(json.dumps({"error":"glob_matched_nothing","glob":args.inglob}, separators=(',', ':')))
            sys.exit(2)
        for fp in files:
            res = run_one(Path(fp), out_root, args.N, args.windows_list, args.kmax, args.Lmax, taus,
                          use_entropy, use_spectral, use_runs, ac_lags, pe_k)
            if "error" in res:
                per_rows.append([res.get("file", Path(fp).name), "ERROR"])
                continue
            per_rows.append([res["file"], res["verdict"]])
            per_hash.append([res["jsonl"], sha256_file(Path(res["jsonl"]))])
            per_hash.append([res["csv"], sha256_file(Path(res["csv"]))])

        # replication table
        rep_dir = out_root / "replication"; rep_dir.mkdir(parents=True, exist_ok=True)
        rep_csv = rep_dir / "replication_summary.csv"
        write_csv(rep_csv, ["file","verdict"], per_rows)

        # aggregate verdicts
        verdicts = [r[1] for r in per_rows if r[1] not in ("ERROR",)]
        all_stable = all(v=="stable" for v in verdicts) and len(verdicts)>0
        any_drift  = any(v=="drift_invariant" for v in verdicts)
        rep_json = rep_dir / "replication_verdict.json"
        with rep_json.open('w', encoding='utf-8') as f:
            f.write(json.dumps({"n": len(verdicts), "all_stable": bool(all_stable), "any_drift": bool(any_drift)}, separators=(',', ':')))

        # manifest of hashes
        manifest_hashes = out_root / "hashes.csv"
        rows = per_hash + [[str(rep_csv), sha256_file(rep_csv)], [str(rep_json), sha256_file(rep_json)]]
        if manifest_path:
            rows.append([str(manifest_path), sha256_file(Path(manifest_path))])
            rows.append([str(out_root / "prereg_manifest.sha256.txt"), sha256_file(out_root / "prereg_manifest.sha256.txt")])
        write_csv(manifest_hashes, ["path","sha256"], rows)

        print(json.dumps({"glob": args.inglob, "n": len(verdicts), "all_stable": all_stable, "any_drift": any_drift, "prereg": bool(manifest_path)}, separators=(',', ':')))
        return

    # single-file branch
    inpath = Path(args.infile)
    res = run_one(inpath, out_root, args.N, args.windows_list, args.kmax, args.Lmax, taus,
                  use_entropy, use_spectral, use_runs, ac_lags, pe_k)
    if "error" in res:
        print(json.dumps(res, separators=(',', ':')))
        sys.exit(2)

    # manifest of hashes
    manifest_hashes = out_root / "hashes.csv"
    rows = [[res["jsonl"], sha256_file(Path(res["jsonl"]))], [res["csv"], sha256_file(Path(res["csv"]))]]
    if manifest_path:
        rows.append([str(manifest_path), sha256_file(Path(manifest_path))])
        rows.append([str(out_root / "prereg_manifest.sha256.txt"), sha256_file(out_root / "prereg_manifest.sha256.txt")])
    write_csv(manifest_hashes, ["path","sha256"], rows)

    print(json.dumps({"file": res["file"], "verdict": res["verdict"], "prereg": bool(manifest_path)}, separators=(',', ':')))

if __name__ == "__main__":
    main()
